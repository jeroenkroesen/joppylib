"""default.py
Default values for various parameters
"""


ITEM_TYPE = 'note'